/*  Find					predicatLs.h					By : deneb, Hugo */

#ifndef PREDICATLS_H
#define PREDICATLS_H

	int print(char* osef, char*path);
	int ls(char* osef, char* path);
	int exec(char* osef, char*path);
	int prune(char* osef, char*path);

#endif
